import Link from 'next/link'

export default function Entradas() {
  return (
    <main className="tickets-page">
      <section className="tickets-section">
        <div className="section-container">
          <h1>Abonos</h1>
          <div className="tickets-grid">
            <div className="ticket-card">
              <h3>Preventa 1</h3>
              <p className="price">$5000</p>
              <ul className="ticket-features">
                <li>Entrada General</li>
                <li>Viernes 25 Junio</li>
                <li>Acceso por San Martin 861</li>
              </ul>
              <Link href="javascript:passline.open()" className="buy-button">Comprar</Link>
            </div>

            <div className="ticket-card">
              <h3>Preventa 2</h3>
              <p className="price">$6000</p>
              <ul className="ticket-features">
                <li>Entrada General</li>
                <li>Viernes 25 Junio</li>
                <li>Acceso por San Martin 861</li>
              </ul>
              <Link href="javascript:passline.open()" className="buy-button">Comprar</Link>
            </div>

            <div className="ticket-card general-card">
              <h3>Abono General</h3>
              <p className="price">$7000</p>
              <ul className="ticket-features">
                <li>Entrada General</li>
                <li>Viernes 25 Junio</li>
                <li>Acceso por San Martin 861</li>
              </ul>
              <Link href="javascript:passline.open()" className="buy-button">Comprar</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}