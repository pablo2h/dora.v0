import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <nav className="navbar">
        <div className="nav-logo">
          <Image 
            src="/assets/images/logo-small.png" 
            alt="logo-small" 
            className="logo-small" 
            width={80} 
            height={80} 
            priority
          />
        </div>
        <button className="menu-toggle" title="Menú">
          <span className="hamburger"></span>
        </button>
      </nav>

      <main>
        <section className="hero">
          <div className="background-images"></div>
          <div className="circles-container">
            <div className="main-circle">
              <Image 
                src="/assets/images/main-circle.png" 
                alt="" 
                className="circle-image" 
                width={600} 
                height={600} 
                priority
              />
            </div>
            <div className="floating-circle circle-1">
              <Image 
                src="/assets/images/circle-1.png" 
                alt="" 
                className="circle-image" 
                width={60} 
                height={60} 
              />
            </div>
            {/* ... other circles ... */}
          </div>

          <div className="content-grid">
            <div className="sponsor-logo">
              {/* Sponsor logo space */}
            </div>
            <p className="event-date">23 Julio</p>
            <div className="festival-logo">
              <Image 
                src="/assets/images/logo-dora.png" 
                alt="DORA Festival" 
                className="logo-main" 
                width={400} 
                height={200} 
                priority
              />
              <p className="subtitle">Edición Groove</p>
            </div>
            <p className="event-location">Vieja Usina, Paraná ER</p>
            <div className="lineup">
              <p>Line UP ★ Line UP</p>
              <p>Line UP ★ Line UP</p>
              <p>Line UP</p>
            </div>
            <Link href="/entradas" className="tickets-button">Entradas</Link>
          </div>
        </section>
      </main>
    </>
  );
}
