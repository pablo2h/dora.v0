import '@/styles/globals.css'
import type { Metadata } from 'next'
import { DynaPuff, Baloo_2, Poppins } from 'next/font/google'

const dynaPuff = DynaPuff({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-dynapuff'
})

const baloo = Baloo_2({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-baloo'
})

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '600'],
  variable: '--font-poppins'
})

export const metadata: Metadata = {
  title: 'Festival Dora - Edición Groove',
  description: 'Festival Dora - El mejor festival de música electrónica en Paraná',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={`${dynaPuff.variable} ${baloo.variable} ${poppins.variable}`}>
      <body>{children}</body>
    </html>
  )
}