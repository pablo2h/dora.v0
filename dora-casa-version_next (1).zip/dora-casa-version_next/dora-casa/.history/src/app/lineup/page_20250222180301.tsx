export default function LineUp() {
  return (
    <main className="lineup-page">
      <h1>Line Up Festival Dora</h1>
      <section className="main-artists">
        {/* Content from your original lineup page */}
      </section>
    </main>
  )
}