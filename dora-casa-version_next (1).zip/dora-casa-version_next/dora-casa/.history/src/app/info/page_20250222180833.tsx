import Image from 'next/image'

export default function Info() {
  return (
    <main className="info-page">
      <h1>Información Festival Dora</h1>

      <section className="event-details">
        <h2>Detalles del Evento</h2>
        <div className="info-grid">
          <article className="location">
            <h3>Ubicación</h3>
            <p>Vieja Usina, San Martín 861, Paraná, Entre Ríos</p>
            <div className="map-container">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1000!2d-60.5238!3d-31.744!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzHCsDQ0JzI4LjQiUyA2MMKwMzEnMjUuNyJX!5e0!3m2!1ses!2sar!4v1234567890!5m2!1ses!2sar" 
                width="600" 
                height="450" 
                style={{ border: 0 }} 
                allowFullScreen 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </article>

          <article className="schedule">
            <h3>Horarios</h3>
            <ul>
              <li>Apertura de puertas: 20:00</li>
              <li>Inicio del evento: 21:00</li>
              <li>Cierre: 06:00</li>
            </ul>
          </article>

          <article className="faq">
            <h3>Preguntas Frecuentes</h3>
            <div className="faq-grid">
              {/* Add your FAQ items here */}
            </div>
          </article>
        </div>
      </section>
    </main>
  )
}