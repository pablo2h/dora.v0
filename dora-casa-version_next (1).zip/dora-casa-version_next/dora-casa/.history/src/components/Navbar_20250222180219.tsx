'use client'

import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <nav className="navbar">
        <div className="nav-logo">
          <Image 
            src="/assets/images/logo-small.png" 
            alt="logo-small" 
            className="logo-small" 
            width={80} 
            height={80} 
            priority
          />
        </div>
        <button 
          className="menu-toggle" 
          title="Menú"
          onClick={() => setIsOpen(!isOpen)}
        >
          <span className="hamburger"></span>
        </button>
      </nav>

      <div className={`nav-panel ${isOpen ? 'open' : ''}`}>
        <div className="nav-links">
          <Link href="/entradas" className="nav-link">Entradas</Link>
          <Link href="/info" className="nav-link">Info</Link>
          <Link href="/lineup" className="nav-link">Line Up</Link>
          <Link href="/blog" className="nav-link">Blog</Link>
          <button className="close-nav" onClick={() => setIsOpen(false)}>
            Cerrar
          </button>
        </div>
      </div>
    </>
  )
}