export default function Footer() {
  return (
    <footer className="footer">
      <div className="community-banner">
        <h2>DISFRUTA NUESTRA COMUNIDAD</h2>
      </div>

      <div className="social-buttons">
        <a href="#instagram" className="social-button instagram">
          <img src="/assets/social/instagram.svg" alt="Instagram" />
        </a>
        <a href="#tiktok" className="social-button tiktok">
          <img src="/assets/social/tiktok.svg" alt="TikTok" />
        </a>
        <a href="#youtube" className="social-button youtube">
          <img src="/assets/social/youtube.svg" alt="YouTube" />
        </a>
        <a href="#kick" className="social-button kick">
          <img src="/assets/social/kick.svg" alt="Kick" />
        </a>
      </div>

      <div className="contact-section">
        <h2>Contactanos</h2>
        <form className="contact-form">
          <div className="form-row">
            <label>Correo Electrónico:</label>
            <input type="email" placeholder="example@mail.com" required />
          </div>
          <div className="form-row">
            <label>Como te llamas:</label>
            <input type="text" placeholder="nombre completo" required />
          </div>
          <div className="form-row">
            <label>¿Porque nos hablamos?</label>
            <input type="text" placeholder="motivo" required />
          </div>
          <button type="submit" className="submit-button">Daleeee!</button>
        </form>
      </div>
    </footer>
  )
}