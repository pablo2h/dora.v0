export const artists = [
    {
        id: 1,
        name: "Rosario Smowing",
        description: "Rosario Smowing es una banda de swing y ska argentina, oriunda de la ciudad de Rosario. Con 18 años de recorrido y 4 discos editados de forma independiente",
        instagram: "https://www.instagram.com/rosariosmowing/",
        spotifyId: "6qCuLVlvJkLRpPJFYRO2mG",
        image: "/assets/images/placeholder.png"
    },
    {
        id: 2,
        name: "Jam de Racing",
        description: "",
        instagram: "https://www.instagram.com/jam_de_racing/",
        instagramPostId: "DE5_IlvxKju",
        image: "/assets/images/placeholder.png"
    },
    {
        id: 3,
        name: "Zacaro y los Puerkos",
        description: "",
        instagram: "https://www.instagram.com/zacaroylospuerkos/",
        spotifyId: "0laV1xchpqQ9rCoooWioos",
        image: "/assets/images/placeholder.png"
    },
    {
        id: 4,
        name: "Saccreblue",
        description: "",
        instagram: "https://www.instagram.com/saccreblue/",
        youtubeId: "knZ3J1yDY3A?si=wsMd28dk6BYC5gXd",
        image: "/assets/images/placeholder.png"
    },
];